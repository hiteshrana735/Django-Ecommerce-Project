from django.shortcuts import render
import urllib 
import json

# Create your views here.
def index(request):
    return render(request, 'index.html')

def result(request):
    if request.method == 'POST':
        search_city = request.POST['city_name']
        source = urllib.request.urlopen('https://api.openweathermap.org/data/2.5/weather?q=' + search_city + '&appid=0b892f82700f99d1bc0c154a4f756cea&units=metric').read()

        list_of_data = json.loads(source)

        context = {
            "city_name" : search_city,
            "country_code" : str(list_of_data['sys']['country']),
            "coordinate" : str(list_of_data['coord']['lon']) + ', ' + str(list_of_data['coord']['lat']),
            "temp" : str(list_of_data['main']['temp']) + 'degree C',
            "pressure" : str(list_of_data['main']['pressure']),
            "humidity" : str(list_of_data['main']['humidity']), 
            "main" : str(list_of_data['weather'][0]['main']),
            "description" : str(list_of_data['weather'][0]['description']),
        }

        return render(request, 'result.html', context)

    
    else :
        return render(request, 'result.html')