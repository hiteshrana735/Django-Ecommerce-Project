text = "This is a new python file. I am calculating words"

print(len(text.split(' ')))