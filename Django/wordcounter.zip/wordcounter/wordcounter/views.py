from django.shortcuts import render

def index(request):
    return render(request, 'index.html')

def show(request):
    text = request.GET['usertext']
    totalwords = len(text.split(' '))
    totalletters = len(text)

    context = {
        'text' : text, 
        'words' : totalwords,
        'letters' : totalletters
    }

    return render(request, 'show.html', context)